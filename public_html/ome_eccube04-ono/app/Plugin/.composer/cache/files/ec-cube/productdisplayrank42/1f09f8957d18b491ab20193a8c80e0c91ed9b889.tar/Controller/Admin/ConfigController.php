<?php

/*
 * This file is part of ProductDisplayRank42
 *
 * Copyright(c) U-Mebius Inc. All Rights Reserved.
 *
 * https://umebius.com/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Plugin\ProductDisplayRank42\Controller\Admin;

use Eccube\Controller\AbstractController;
use Eccube\Repository\Master\ProductListOrderByRepository;
use Plugin\ProductDisplayRank42\Form\Type\Admin\ConfigType;
use Plugin\ProductDisplayRank42\Repository\ConfigRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ConfigController extends AbstractController
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    /**
     * @var ProductListOrderByRepository
     */
    protected $productListOrderByRepository;

    /**
     * ConfigController constructor.
     */
    public function __construct(
        ProductListOrderByRepository $productListOrderByRepository,
        ConfigRepository $configRepository
    ) {
        $this->configRepository = $configRepository;
        $this->productListOrderByRepository = $productListOrderByRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/product_display_rank42/config", name="product_display_rank42_admin_config")
     * @Template("@ProductDisplayRank42/admin/config.twig")
     */
    public function index(Request $request)
    {
        $Config = $this->configRepository->get();
        $form = $this->createForm(ConfigType::class, $Config);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $Config = $form->getData();
            $this->entityManager->persist($Config);
            $this->entityManager->flush($Config);

            if ($Config->getProductListOrderById()) {
                $ProductListOrderBy = $this->productListOrderByRepository->find($Config->getProductListOrderById());
                $ProductListOrderBy->setName($Config->getName());
                $this->entityManager->flush($ProductListOrderBy);
            }

            $this->addSuccess('登録しました。', 'admin');

            return $this->redirectToRoute('product_display_rank42_admin_config');
        }

        return [
            'form' => $form->createView(),
        ];
    }
}
